# 📘 Experiment 5.1 — CRUD Operations for Product Database Using Mongoose

## 🧩 Objective

This section documents the step-by-step process and corresponding screenshots for **Experiment 5.1**.

## 🪜 Steps and Screenshots

### Step 1:

<img width="731" height="537" alt="5 1(a)" src="https://github.com/user-attachments/assets/21c7342d-1f92-4f54-86cb-62210da277e2" />

### Step 2:  


<img width="787" height="343" alt="5 1(b)" src="https://github.com/user-attachments/assets/5ad7a0e6-d77e-4baa-976a-fb7bfef07d0a" />



### Step 3:


<img width="793" height="298" alt="5 1(c)" src="https://github.com/user-attachments/assets/b01cf7aa-3e92-47b0-b735-44e0df81135a" />


### ✍️ Made By: **Rohit Gupta**
